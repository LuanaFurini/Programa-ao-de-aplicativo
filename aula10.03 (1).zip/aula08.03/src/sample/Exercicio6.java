package sample;

public class Exercicio6 {
}
