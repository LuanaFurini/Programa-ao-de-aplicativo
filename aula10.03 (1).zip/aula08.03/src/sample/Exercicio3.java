package sample;

public class Exercicio3 {
    public static void main(String[]args) {
        imprimir1_100();
    }
    public static void imprimir1_100(){
        for(int i=1; i<=100; i++){
            System.out.print(i + " ");
        }
        System.out.println("");;
    }
    public static void imprimir101_200(){
        for(int i=1; i<=200; i++){
            System.out.print(i + " ");
        }
    }
}
