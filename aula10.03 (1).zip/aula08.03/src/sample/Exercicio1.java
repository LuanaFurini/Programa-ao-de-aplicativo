package sample;




public class Exercicio1 {


    public static void main(String[] args) {
        int n1 = 10, n2 = 10;
        int n3 = produto(n1, n2);
        System.out.println("Produto: " + n3);

    }

    public static int produto(int a, int b) {
        int c = a * b;
        return c;
    }

}