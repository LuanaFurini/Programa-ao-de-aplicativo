package sample;

public class Exercicio4 {

        public static void main (String[] args) {

            int[]num1 = new int[5];
            num1[0] = 10;
            num1[1] = 20;
            num1[2] = 30;
            num1[3] = 40;
            num1[4] = 50;

            for(int i=0; i<5; i++)
                System.out.print(num1[i] + " ");

                System.out.println("\n");
            int []num2 = {10, 20, 30, 40, 50};
            for(int i=0; i<5; i++)
                System.out.print(num2[i] + " ");

                System.out.print("\n");
            int []num3 = new int[5];
            for(int i=0; i<5; i++){
                num3[i] = num1[i] + num2[i];
                System.out.print(num3[i] + " ");
            }
        }

}
