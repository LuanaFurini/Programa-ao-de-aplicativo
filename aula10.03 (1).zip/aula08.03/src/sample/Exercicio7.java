package sample;

public class Exercicio7 {
}
