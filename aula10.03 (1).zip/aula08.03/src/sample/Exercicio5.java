package sample;

public class Exercicio5 {
}
