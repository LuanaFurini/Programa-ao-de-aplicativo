package sample;

public class Exercicio2 {
    public static void main (String[]args){
        System.out.println("Divisão: " + divisao(10.0,5.0));
    }



}
