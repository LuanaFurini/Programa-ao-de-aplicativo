package resolucaolistadexercicio;



public class ResolucaoListaExercicio {
    public static void main (String[] args){

        int numeroConta = 12345;
        String nomeTitular = "Felipe Reis";
        char temDeposito = 's';
        double valor = 0.0;

        if(temDeposito == 's'){
            valor = 500.00;
        }

        Conta felipe = new Conta(numeroConta,nomeTitular, valor);
        System.out.println("Dados da Conta:");
        felipe.imprimir();

        felipe.deposito(200);
        System.out.println("Dados da Conta Atualizado:");
        felipe.imprimir();

        felipe.saque(300);
        System.out.println("Dados da Conta Atualizado:");
        felipe.imprimir();


    }
}
